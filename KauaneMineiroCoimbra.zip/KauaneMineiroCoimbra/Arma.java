// a parte 10 do trabalho que inclui as armas


import java.util.Random;

public abstract class Arma {

    private String nome;
    private int ataque;
    private int chance;

    public Arma(String nome, int ataque, int chance) {
        this.nome = nome;
        this.ataque = ataque;
        this.chance = chance;
    }
    public Arma(String nome, int ataque) {
        this(nome, ataque, 100);
    }

    public String getNome() { return this.nome; }

    public boolean podeUsar(){ return true; }
    protected String textoMunicao(){ return "munição: ilimitada"; }
    public void restaurar(){}

    public void aumentarAtaque( int percentual ){
        this.ataque += this.ataque * percentual / 100;
    }

    public void mensagem(){
        System.out.println( this.nome + " - dano: " + this.ataque
                + " - chance: " + this.chance + "% - " + textoMunicao() );
    }

    public void fazAtaque( Criatura criatura ){
        Random rd = new Random();
        if( rd.nextInt(100) < this.chance ){
            criatura.tomaDano(this.ataque);
        } else {
            System.out.println("Errou!");
        }
    }
}
//10. Arma.java
//Classe abstrata de toda arma. Guarda nome, ataque e chance de acerto (padrao 100%). 
//fazAtaque() sorteia se acertou. Se sim, causa o dano. Se nao, imprime “Errou!”.
//podeUsar() devolve true por padrao e textoMunicao() devolve “ilimitada”.
//  As armas de longo alcance sobrescrevem esses dois.
//mensagem() mostra a linha do menu (nome, dano, chance, municao).
//aumentarAtaque(percentual) e restaurar() sao usados no upgrade e entre as batalhas.