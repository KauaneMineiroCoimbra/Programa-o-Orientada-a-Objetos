//a parte 11 que desenvolve o trabalho comn outra arma
// Arma com municao limitada
public abstract class ArmaDeLongoAlcance extends Arma {

    private int municao;
    private int municaoMaxima;

    public ArmaDeLongoAlcance(String nome, int ataque, int chance, int municao) {
        super(nome, ataque, chance);
        this.municao = municao;
        this.municaoMaxima = municao;
    }

    @Override
    public boolean podeUsar(){ return this.municao > 0; }

    @Override
    protected String textoMunicao(){
        if( this.municao <= 0 ){
            return "municao: 0/" + this.municaoMaxima + " (SEM MUNICAO)";
        }
        return "municao: " + this.municao + "/" + this.municaoMaxima;
    }

    @Override
    public void fazAtaque( Criatura criatura ){
        if( !podeUsar() ){
            System.out.println(getNome() + " esta sem municao!");
            return;
        }
        this.municao--; // gasta municao mesmo se errar
        super.fazAtaque(criatura);
    }

    @Override
    public void restaurar(){ this.municao = this.municaoMaxima; }

    public void aumentarMunicao( int quantidade ){
        this.municaoMaxima += quantidade;
        this.municao += quantidade;
    }
}


//11. ArmaDeLongoAlcance.java

//Filha de Arma, acrescenta municao (municao e municaoMaxima).

//podeUsar() so e  verdadeiro se houver municao.
//fazAtaque() gasta 1 municao mesmo se errar. Sem municao, avisa e nao ataca.
//  Depois chama super.fazAtaque() para o sorteio normal.
//textoMunicao() mostra “7/8”, ou “SEM MUNICAO” quando acaba.
//restaurar() recarrega tudo. aumentarMunicao() aumenta o maximo (upgrade).