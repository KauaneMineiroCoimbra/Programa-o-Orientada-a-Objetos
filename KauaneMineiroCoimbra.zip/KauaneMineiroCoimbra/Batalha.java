public class Batalha {
// a parte 15 que contem da luta que fica no main recebe o numero da batalha 
    private int numero;
    private Heroi heroi;
    private Inimigo inimigo;
    private int rodadas;
    private boolean heroiVenceu;
    private int vidaFinal;

    public Batalha(int numero, Heroi heroi, Inimigo inimigo) {
        this.numero = numero;
        this.heroi = heroi;
        this.inimigo = inimigo;
    }

    public boolean heroiVenceu() { return this.heroiVenceu; }

    public void executar() {
        System.out.println("\n################");
        System.out.println("Batalha " + numero + ": " + heroi.getNome() + " x " + inimigo.getNome());
        System.out.println("################\n");

        heroi.fraseApresentacao();
        inimigo.fraseApresentacao();

        while(true){
            rodadas++;
            System.out.println("\n--- Rodada " + rodadas + " ---");
            heroi.mostraVida();
            inimigo.mostraVida();

            heroi.fazAtaque(inimigo);
            if( inimigo.estaVivo() ){
                inimigo.fazAtaque(heroi);
            }

            if( !heroi.estaVivo() ){
                heroi.fraseMorte();
                System.out.println(inimigo.getNome() + " venceu.");
                heroiVenceu = false;
                break;
            }
            if( !inimigo.estaVivo() ){
                inimigo.fraseMorte();
                System.out.println(heroi.getNome() + " venceu.");
                heroiVenceu = true;
                break;
            }

            heroi.upgrade();
            inimigo.upgrade();
        }
        vidaFinal = heroi.getVida();
    }

    public void imprimeResultado() {
        System.out.println("Batalha " + numero + " (" + heroi.getNome() + " x " + inimigo.getNome() + "): "
                + (heroiVenceu ? "VITORIA" : "DERROTA") + " em " + rodadas
                + " rodada(s) - vida restante: " + vidaFinal);
    }
}

//a parte 15 que fica o main e recebe onumero da batalha
//o heroi e o inimigo. que executar() apresenta os dois e entra num loop. A cada rodada o heroi ataca e,
//  se o inimigo ainda estiver vivo,
//  ele contra-ataca. Depois verifica quem morreu e, se ninguem morreu, chama upgrade() dos dois.
//Guarda o resultado (quem venceu, rodadas, vida final) e imprimeResultado() mostra isso no resumo final.