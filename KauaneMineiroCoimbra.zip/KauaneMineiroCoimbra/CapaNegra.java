// a parte 5. do trabalho que começa com a capa negra que usa a composicao


// Defesa mista (bloqueio + esquiva): a capa tenta se desviar do golpe
// e, se não conseguir, ainda amortece parte do dano.
public class CapaNegra extends Defesa {
    private TampaDePanela bloqueio;
    private Esquiva esquiva;

    public CapaNegra(int reducao, int chanceEsquiva) {
        this.bloqueio = new TampaDePanela(reducao);
        this.esquiva = new Esquiva(chanceEsquiva);
    }

    @Override
    public int danoReduzido( int dano ){
        int depoisDaEsquiva = this.esquiva.danoReduzido(dano);
        if( depoisDaEsquiva == 0 ){
            return 0;
        }
        int depoisDoBloqueio = this.bloqueio.danoReduzido(depoisDaEsquiva);
        if( depoisDoBloqueio < depoisDaEsquiva ){
            System.out.println("A capa amorteceu o golpe!");
        }
        return depoisDoBloqueio;
    }
}
//É a defesa mista, que usa composição: tem dentro de si uma TampaDePanela e uma Esquiva. 
// Primeiro tenta esquivar. Se esquivou, o dano é 0. Se não,
//  o bloqueio reduz o dano e imprime “A capa amorteceu o golpe!”.