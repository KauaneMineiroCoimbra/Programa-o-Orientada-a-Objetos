public class Chinelo extends Arma {
    public Chinelo() {
        super("Chinelo (chinelada!)", 70, 90);
    }
}

// a part.12 do trabablho que sao as 6 armas 
// ela e a preimira e mais curta	70dano	90%chance	ilimitada(municao)