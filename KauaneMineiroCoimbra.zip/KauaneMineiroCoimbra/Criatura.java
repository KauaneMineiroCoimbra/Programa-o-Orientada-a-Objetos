// a parte 1 do trabalho começa coma criatura.

public abstract class Criatura {
    private String nome;
    private int vida;
    private int vidaMaxima;
// a critutra começa É a classe-base de tudo que luta (herói e inimigos).

//Guarda nome, vida e vidaMaxima. A vida máxima serve para restaurar o personagem entre as batalhas.
//Tem três métodos abstratos que cada filho é obrigado a implementar: fraseApresentacao(), fraseMorte() e fazAtaque().
//tomaDano() subtrai a vida e impede que ela fique negativa.
//restaurarVida() volta ao máximo. aumentarVidaMaxima() aumenta o máximo e já cura essa quantidade (usado no upgrade).
//upgrade() está vazio de propósito. Quem quiser mudar durante a luta (como o Rei Pesadelo) sobrescreve.
public Criatura(String nome, int vida) {
        this.nome = nome;
        this.vida = vida;
        this.vidaMaxima = vida;
    }

    public abstract void fraseApresentacao();
    public abstract void fraseMorte();
    public abstract void fazAtaque( Criatura criatura );

    public void mostraVida(){
        System.out.println(this.nome + ": " + this.vida + " pontos de vida.");
    }
    public String getNome() { return this.nome; }
    public int getVida() { return this.vida; }
    public boolean estaVivo() { return this.vida > 0; }

    public void tomaDano(int dano){
        this.vida -= dano;
        if( this.vida < 0 ){ this.vida = 0; }
        System.out.println(this.nome + " toma " + dano + " de dano.");
    }
    public boolean vidaCritica( int valorCritico ){
        return this.vida < valorCritico;
    }
    public void restaurarVida(){
        this.vida = this.vidaMaxima;
    }
    public void aumentarVidaMaxima( int quantidade ){
        this.vidaMaxima += quantidade;
        this.vida += quantidade;
    }
    public void upgrade(){}
}
