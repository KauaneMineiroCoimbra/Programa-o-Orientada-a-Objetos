//2 parte que começa com a Defesa

public class Defesa {
    public int danoReduzido( int dano ){
        return dano;
    }
}

//É a defesa “nula”: danoReduzido(dano)
//  devolve o mesmo dano, sem reduzir nada. As outras defesas herdam dela e mudam esse método.