import java.util.Scanner;

// a parte 13 do trabalho que Centraliza a leitura do teclado com um 
// unico Scanner, o que evita problemas de ter varios lendo o mesmo teclado.
//lerTexto() nao aceita nome vazio.

// Um Unico Scanner compartilhado pelo programa todo
public class Entrada {
    private static Scanner sc = new Scanner(System.in);

    public static String lerTexto( String mensagem ){
        System.out.print(mensagem);
        String texto = sc.nextLine().trim();
        while( texto.isEmpty() ){
            System.out.print("Nao pode ficar vazio. Digite novamente: ");
            texto = sc.nextLine().trim();
        }
        return texto;
    }

    public static int lerInt( int min, int max ){
        while( true ){
            try {
                int valor = Integer.parseInt(sc.nextLine().trim());
                if( valor >= min && valor <= max ){ return valor; }
            } catch( NumberFormatException e ){ }
            System.out.print("Numero invalido. Digite novamente: ");
        }
    }
}
//lerInt(min, max) repete a pergunta ate receber um numero valido.
//  Se o usuario digitar letra,
//  ela captura o erro e pede de novo, sem travar.