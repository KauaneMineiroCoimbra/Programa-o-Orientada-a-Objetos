public class EspadaDeEspuma extends Arma {
    public EspadaDeEspuma() {
        super("Espada de espuma", 90, 85);
    }
}


//; parte '12' do trabalho com as 6 armas, com a 3 arma mais curta
//com 90 de dano 
//chance 85%
//municao ilimitada 