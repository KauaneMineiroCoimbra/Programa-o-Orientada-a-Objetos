import java.util.Random;
// a parte 4 do trabalho que comçea com o esquiva 
// Defesa de esquiva: chance de não tomar dano nenhum
public class Esquiva extends Defesa {
    private int chance;

    public Esquiva(int chance){
        if( chance < 0 ){ chance = 0; }
        else if( chance > 100 ){ chance = 100; }
        this.chance = chance;
    }

    @Override
    public int danoReduzido( int dano ){
        Random rd = new Random();
        if( rd.nextInt(100) < this.chance ){
            System.out.println("Esquivou!!");
            return 0;
        }
        return dano;
    }
}

// com a defesa É a defesa de esquiva. Sorteia um número de 0 a 99.
//  Se for menor que a chance, imprime “Esquivou!!” e o dano vira 0.
//  O construtor limita a chance entre 0 e 100.