public class Estilingue extends ArmaDeLongoAlcance {
    public Estilingue() {
        super("Estilingue", 180, 55, 8);
    }
}
// parte '12' do trabalho comk as 6 armas, com a 4 arma mais longo tipo
//com 180 de dano 
//chance 55%
//municao 8 