// a continuacao com a parte 8 da construcao do trabalho com a fastama 

public class FantasmaLencol extends Inimigo {

    public FantasmaLencol() {
        super("Fantasma Lençol", 500, 75, new Esquiva(30));
    }

    @Override
    public void fraseApresentacao() {
        System.out.println("Buuuu! Você não me pega, sou invisível... quase!");
    }

    @Override
    public void fraseMorte() {
        System.out.println("Fui parar na máquina de lavar... aaaah...");
    }
}
//8. FantasmaLencol.java (inimigo 2)

//Vida 500, ataque 75, defesa Esquiva(30).
//  Só tem as frases e o construtor; 
// o comportamento especial dele é a esquiva.