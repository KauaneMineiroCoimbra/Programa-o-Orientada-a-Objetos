public class Heroi extends Criatura {
// a parte 14 do trabalho que e o filho da criatura
    private Arma[] armas;
    private ArmaDeLongoAlcance armaLonga;

    public Heroi(String nome, Arma armaCurta, ArmaDeLongoAlcance armaLonga ) {
        super(nome, 1000);
        this.armaLonga = armaLonga;
        this.armas = new Arma[]{ armaCurta, armaLonga };
    }

    @Override
    public void fazAtaque(Criatura criatura) {
        System.out.println("Escolha sua arma:");
        for( int i = 0; i < armas.length; i++ ){
            System.out.print( (i + 1) + ") " );
            armas[i].mensagem();
        }
        System.out.print("Opcao: ");
        int escolha = Entrada.lerInt(1, armas.length);
        while( !armas[escolha-1].podeUsar() ){
            System.out.print("Essa arma esta sem municao. Escolha outra: ");
            escolha = Entrada.lerInt(1, armas.length);
        }
        armas[escolha-1].fazAtaque(criatura);
    }

    @Override
    public void fraseApresentacao() {
        System.out.println("De pijama, mas pronto pra luta!");
    }

    @Override
    public void fraseMorte() {
        System.out.println("Zzzzzz... (caiu no sono)");
    }

    // Vida e municoes voltam ao inicial entre as batalhas
    public void restaurar() {
        restaurarVida();
        for( Arma arma : armas ){ arma.restaurar(); }
    }

    // Upgrade escolhido pelo jogador
    public void receberUpgrade() {
        System.out.println("\n*** A VOVO TE DEU UM PRESENTE! Escolha um: ***");
        System.out.println("1) Pijama de super-heroi: +300 de vida maxima");
        System.out.println("2) Pilhas novas: +30% de dano em todas as armas");
        System.out.println("3) Mochila maior: +5 de municao em " + armaLonga.getNome());
        System.out.print("Opcao: ");
        switch( Entrada.lerInt(1, 3) ){
            case 1:
                aumentarVidaMaxima(300);
                System.out.println("Voce se sente super resistente!");
                break;
            case 2:
                for( Arma arma : armas ){ arma.aumentarAtaque(30); }
                System.out.println("Suas armas estao mais fortes!");
                break;
            default:
                armaLonga.aumentarMunicao(5);
                System.out.println("Agora cabe mais municao!");
        }
        System.out.println();
    }
}


//etapa da parte 14 e o jogador, filho de Criatura, com 1000 de vida. Recebe uma arma curta e uma longa, 
// e guarda as duas num vetor.
//fazAtaque() mostra o menu com a municao de todas as armas,
//  la a escolha e nao deixa escolher arma sem municao.
//restaurar() devolve vida e municao de todas as armas.
//receberUpgrade() oferece tres opcoes: +300 de vida maxima,
//  +30% de dano em todas as armas ou +5 de municao na arma longa.