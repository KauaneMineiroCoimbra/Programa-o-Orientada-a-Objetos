//a parte 6- começa com o inimigo que a filha da criatura

public abstract class Inimigo extends Criatura {

    private int ataque;
    private Defesa defesa;

    public Inimigo(String nome, int vida, int ataque) {
        super(nome, vida);
        this.ataque = ataque;
        this.defesa = new Defesa(); // defesa nula
    }
    public Inimigo(String nome, int vida, int ataque, Defesa defesa) {
        super(nome, vida);
        this.ataque = ataque;
        this.defesa = defesa;
    }

    @Override
    public void fazAtaque(Criatura criatura) {
        criatura.tomaDano(this.ataque);
    }

    @Override
    public void tomaDano( int dano ){
        super.tomaDano(this.defesa.danoReduzido(dano));
    }

    public int getAtaque() { return this.ataque; }
    public void setAtaque(int ataque) { this.ataque = ataque; }
    public void setDefesa(Defesa defesa) { this.defesa = defesa; }
}


//Filha de Criatura e mãe de todos os monstros. Acrescenta ataque e defesa.
//Dois construtores: um sem defesa (usa a Defesa nula) e outro que recebe uma defesa.
//fazAtaque() causa o dano fixo de ataque.
//tomaDano() passa o dano pela defesa antes de aplicá-lo,
//  por isso qualquer inimigo se defende sem código extra.
//Tem getAtaque(), setAtaque() e setDefesa() para os filhos mudarem esses valores.