import java.util.ArrayList;
// A PARTE 16 E O JOGO da classe main que controla o fluco do jogo, que pede o nome
//e as duas armas (escolheArmaCurta() e escolheArmaLonga()).
public class Jogo {

    private static Arma escolheArmaCurta() {
        System.out.println("\nEscolha sua arma de curta distância:");
        System.out.println("1) Chinelo       (dano 70, chance 90%)");
        System.out.println("2) Travesseiro   (dano 40, chance 100%)");
        System.out.println("3) Espada de espuma (dano 90, chance 85%)");
        System.out.print("Opcao: ");
        switch( Entrada.lerInt(1, 3) ){
            case 1:  return new Chinelo();
            case 2:  return new Travesseiro();
            default: return new EspadaDeEspuma();
        }
    }

    private static ArmaDeLongoAlcance escolheArmaLonga() {
        System.out.println("\nEscolha sua arma de longa distância:");
        System.out.println("1) Estilingue      (dano 180, chance 55%, 8 bolinhas)");
        System.out.println("2) Pistola de água (dano 130, chance 75%, 7 cargas)");
        System.out.println("3) Lança-tortas    (dano 160, chance 65%, 6 tortas)");
        System.out.print("Opção: ");
        switch( Entrada.lerInt(1, 3) ){
            case 1:  return new Estilingue();
            case 2:  return new PistolaDeAgua();
            default: return new LancaTortas();
        }
    }

    public static void main(String[] args){

        System.out.println("=== A NOITE DO PIJAMA HEROI ===");
        System.out.println("São 3 da manhã e monstros invadiram a sua casa!\n");

        String nome = Entrada.lerTexto("Digite o nome do seu herói: ");
        Arma armaCurta = escolheArmaCurta();
        ArmaDeLongoAlcance armaLonga = escolheArmaLonga();

        Heroi heroi = new Heroi(nome, armaCurta, armaLonga);

        Inimigo[] inimigos = {
            new MonstroDoArmario(),
            new FantasmaLencol(),
            new ReiPesadelo()
        };

        ArrayList<Batalha> batalhas = new ArrayList<>();

        for( int i = 0; i < inimigos.length; i++ ){
            if( i == 2 ){
                heroi.receberUpgrade(); // upgrade antes da 3ª batalha
            }

            Batalha batalha = new Batalha(i + 1, heroi, inimigos[i]);
            batalha.executar();
            batalhas.add(batalha);

            if( !batalha.heroiVenceu() ){
                break;
            }
            heroi.restaurar();
        }

        System.out.println("\n================ RESULTADO ================");
        for( Batalha b : batalhas ){
            b.imprimeResultado();
        }
        if( heroi.estaVivo() ){
            System.out.println("\nO sol nasceu! " + heroi.getNome() + " salvou a casa dos pesadelos!");
        } else {
            System.out.println("\n" + heroi.getNome() + " pegou no sono... Fim de jogo.");
        }
    }
}
//e a classe do main e controla o fluxo do jogo:Pede o nome e as duas armas (escolheArmaCurta() e escolheArmaLonga()).
//Cria o heroi e a lista dos 3 inimigos.
//Percorre os inimigos num for. No indice 2 (a 3 batalha), chama receberUpgrade() antes de lutar.
//Cria e executa cada Batalha e guarda numa lista. Se o heroi perde, o break encerra o loop. Se vence, chama heroi.restaurar().
//No fim, imprime o resultado de cada batalha e a mensagem final.