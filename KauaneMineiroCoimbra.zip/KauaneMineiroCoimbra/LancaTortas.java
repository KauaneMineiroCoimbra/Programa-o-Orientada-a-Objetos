public class LancaTortas extends ArmaDeLongoAlcance {
    public LancaTortas() {
        super("Lanca-tortas", 160, 65, 6);
    }
}
//; parte '12' do trabalho comk as 6 armas, com a 6 arma mais longo tipo
//com 160 de dano 
//chance 65%
//municao 6