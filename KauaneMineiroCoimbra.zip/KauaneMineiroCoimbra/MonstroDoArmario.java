import java.util.Random;

public class MonstroDoArmario extends Inimigo {

    private Random rd = new Random();

    public MonstroDoArmario() {
        super("Monstro do Armário", 450, 70, new TampaDePanela(10));
    }

    @Override
    public void fraseApresentacao() {
        System.out.println("GRRR! Ninguém dorme na minha casa!");
    }

    @Override
    public void fraseMorte() {
        System.out.println("Buá! Vou me esconder debaixo da cama...");
    }

    // JUSTIFICATIVA: o monstro é desajeitado e imprevisível, então o
    // ataque dele não é fixo: o dano é sorteado entre 30 e 110 a cada
    // golpe (às vezes só faz cócegas, às vezes dá um susto enorme).
    @Override
    public void fazAtaque(Criatura criatura) {
        int dano = 30 + rd.nextInt(81);
        System.out.println(getNome() + " balança as garras sem pensar...");
        criatura.tomaDano(dano);
    }
}
