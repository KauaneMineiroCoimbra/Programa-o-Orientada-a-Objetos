public class PistolaDeAgua extends ArmaDeLongoAlcance {
    public PistolaDeAgua() {
        super("Pistola de água", 130, 75, 7);
    }
}


//; parte '12' do trabalho comk as 6 armas, com a 5 arma mais longo tipo
//com 130 de dano 
//chance 75%
//municao 7