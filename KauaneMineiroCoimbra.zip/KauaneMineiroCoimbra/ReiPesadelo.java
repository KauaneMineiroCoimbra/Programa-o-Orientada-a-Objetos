//  aparte 9 que e o inimigo 3 o chefe 
public class ReiPesadelo extends Inimigo {

    public ReiPesadelo() {
        // Defesa mista: bloqueio de 10 + 15% de esquiva
        super("Rei Pesadelo", 750, 80, new CapaNegra(10, 15));
    }

    @Override
    public void fraseApresentacao() {
        System.out.println("Eu sou o fim de todos os sonhos bons!");
    }

    @Override
    public void fraseMorte() {
        System.out.println("Acordei... eraso um sonho ruim...");
    }

    //--Sistema de Upgrade: com a vida baixa, o Rei entra em pânico e ataca com mais fúria
    private boolean upgraded = false;
    private int vidaCritica = 200;
    @Override
    public void upgrade(){
        if( !upgraded && vidaCritica(vidaCritica) ){
            System.out.println(getNome() + " enlouqueceu de raiva!");
            upgraded = true;
            setAtaque(125);
        }
    }
}
//ReiPesadelo.java (inimigo 3, o chefe)
//Vida 750, ataque 80, defesa mista CapaNegra(10, 15).
//Sobrescreve upgrade(), que e  chamado no fim de cada rodada. Quando a vida cai abaixo de 200, ele “enlouquece” e o ataque sobe para 125.
//A variavel upgraded garante que isso aconteça um unica vez.