// Defesa de bloqueio: reduz uma quantidade fixa de dano

// a parte 3 do trabalho com a criacao da tampadepanela
public class TampaDePanela extends Defesa {
    private int reducao;

    public TampaDePanela(int reducao){
        if( reducao < 0 ){ reducao = 0; }
        this.reducao = reducao;
    }

    @Override
    public int danoReduzido( int dano ){
        if( dano < this.reducao ){ return 0; }
        return dano - this.reducao;
    }
}

//É a defesa de bloqueio. Subtrai uma quantidade fixa do dano e nunca devolve valor negativo.
//  Com redução 10 e um golpe de 70, o dano final é 60.