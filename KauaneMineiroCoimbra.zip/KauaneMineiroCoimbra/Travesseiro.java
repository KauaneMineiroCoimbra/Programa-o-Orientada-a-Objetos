public class Travesseiro extends Arma {
    public Travesseiro() {
        super("Travesseiro", 40);
    }
}


//; parte '12' do trabalho comk as 6 armas, com a 2 arma mais curta
//com 40 de dano 
//chance 100%
//municao ilimitada 