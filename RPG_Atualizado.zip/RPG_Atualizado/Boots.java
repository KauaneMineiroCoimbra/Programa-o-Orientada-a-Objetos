// ============================================================
// Boots.java
// O chefão do jogo: o Monstro das Ferramentas Perdidas.
// ============================================================
public class Boots extends Inimigo {

    // Construtor ANTIGO: Boots com força "padrão" (360 de vida, 35 de ataque).
    public Boots() {
        super("Boots, o Monstro das Ferramentas Perdidas", 360, 35);
    }

    // (NOVO) Construtor com DIFICULDADE: ajusta vida e ataque conforme o nível escolhido.
    // Fácil deixa o Boots mais fraco; Difícil deixa mais forte.
    public Boots(Dificuldade dificuldade) {
        super("Boots, o Monstro das Ferramentas Perdidas",
              dificuldade.ajustaVida(360),
              dificuldade.ajustaAtaque(35));
    }

    @Override
    public void fraseApresentacao() {
        System.out.println("\nBOOTs: BIIIIIP! BZZZT! Quem ousa mexer no meu jardim?");
        System.out.println("BOOTs: Eu sou o guardiao dos comandos perdidos!");
    }

    @Override
    public void fraseMorte() {
        System.out.println("\nBOOTs: Bzz... talvez... eu só precisasse de uma manutenção...");
        System.out.println("BOOTs se desfaz em pequenas engrenagens luminosas.");
    }
}
