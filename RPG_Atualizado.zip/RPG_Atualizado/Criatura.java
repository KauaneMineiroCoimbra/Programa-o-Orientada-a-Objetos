// ============================================================
// Criatura.java
// Classe-mãe de TODOS os seres do jogo: jogador, inimigos e NPCs.
// Tudo que é "vivo" tem nome e vida, então isso fica aqui.
// É "abstract": não dá para criar uma "Criatura" solta,
// só as filhas dela (Jogador, Boots, Mentor...).
// ============================================================
public abstract class Criatura {
    private String nome;       // nome da criatura
    private int vida;          // vida atual
    private int vidaMaxima;    // vida máxima (a vida inicial)

    // Construtor: define o nome e começa com a vida cheia.
    public Criatura(String nome, int vida) {
        this.nome = nome;
        this.vida = vida;
        this.vidaMaxima = vida;
    }

    public String getNome() {
        return nome;
    }

    public int getVida() {
        return vida;
    }

    // (NOVO) Permite saber a vida máxima. Útil para o robô decidir quando se curar.
    public int getVidaMaxima() {
        return vidaMaxima;
    }

    // Métodos abstratos: cada filha é obrigada a escrever o seu.
    public abstract void fazAtaque(Criatura criatura);
    public abstract void fraseApresentacao();
    public abstract void fraseMorte();

    // Tira vida da criatura. A vida nunca fica abaixo de zero.
    public void tomaDano(int dano) {
        vida -= dano;
        if (vida < 0) {
            vida = 0;
        }
        System.out.println(nome + " recebeu " + dano + " de dano.");
    }

    // Devolve vida. A vida nunca passa do máximo.
    public void cura(int quantidade) {
        vida += quantidade;
        if (vida > vidaMaxima) {
            vida = vidaMaxima;
        }
    }

    // Retorna true se ainda tem vida.
    public boolean estaVivo() {
        return vida > 0;
    }

    // Mostra a vida na tela. Ex.: "Julia - Vida: 80/120"
    public void mostraVida() {
        System.out.println(nome + " - Vida: " + vida + "/" + vidaMaxima);
    }

    // Deixa a vida no máximo de novo.
    public void restauraVida() {
        vida = vidaMaxima;
    }
}
