import java.util.Random;

// ============================================================
// CristalElemento.java  (NOVO)
// Um tipo de Item ligado aos ELEMENTOS (água, fogo, terra, vento).
// Ao usar o cristal, o poder daquele elemento aumenta.
// ============================================================
public class CristalElemento extends Item {
    private static final int BONUS = 6;   // quanto o poder aumenta
    private String elemento;              // agua, fogo, terra ou vento

    public CristalElemento(String elemento) {
        super("Cristal de " + nomeBonito(elemento),
              "Aumenta em " + BONUS + " o poder de " + nomeBonito(elemento) + ".");
        this.elemento = elemento;
    }

    // Transforma "agua" em "Água" (com acento) para mostrar na tela.
    private static String nomeBonito(String elemento) {
        if (elemento.equals("agua")) return "Água";
        if (elemento.equals("fogo")) return "Fogo";
        if (elemento.equals("terra")) return "Terra";
        return "Vento";
    }

    // Escolhe um elemento ao acaso e cria o cristal dele.
    public static CristalElemento sortear(Random sorteio) {
        String[] elementos = {"agua", "fogo", "terra", "vento"};
        int posicao = sorteio.nextInt(elementos.length);  // número de 0 a 3
        return new CristalElemento(elementos[posicao]);
    }

    // O que acontece quando o jogador usa o cristal.
    @Override
    public void usar(Jogador jogador) {
        System.out.println("💎 O cristal brilha e o poder de " + nomeBonito(elemento) + " aumenta!");
        jogador.aumentarPoder(elemento, BONUS);
    }
}
