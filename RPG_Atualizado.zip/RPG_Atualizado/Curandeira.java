// ============================================================
// Curandeira.java  (NOVO)
// Tipo de NPC: a Fada Lumi, que cura o jogador antes da batalha
// final e ainda deixa uma poção extra na mochila.
// ============================================================
public class Curandeira extends Npc {

    public Curandeira() {
        super("Fada Lumi");
    }

    @Override
    public void fraseApresentacao() {
        System.out.println("Fada Lumi: Plim plim! Sou a curandeira de Vale-Lume.");
    }

    @Override
    public void interagir(Jogador jogador) {
        System.out.println("Fada Lumi: Vi que você vai enfrentar algo perigoso. Deixe-me ajudar!");
        jogador.restauraVida();                   // devolve toda a vida
        System.out.println("✨ A fada te cura completamente!");
        jogador.ganharItem(new PocaoCura());      // e dá uma poção extra
    }
}
