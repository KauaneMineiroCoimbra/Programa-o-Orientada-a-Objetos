// ============================================================
// Dificuldade.java  (NOVO)
// Define os NÍVEIS DE DIFICULDADE do jogo: Fácil, Normal e Difícil.
//
// Um "enum" é uma lista de opções fixas. Aqui cada opção
// (FACIL, NORMAL, DIFICIL) guarda números que mudam o jogo:
//   - quanta vida o jogador começa;
//   - o quanto o inimigo fica mais fraco/forte;
//   - um multiplicador de pontos para o ranking.
// ============================================================
public enum Dificuldade {

    // nome na tela, vida do jogador, multiplicador de vida do inimigo,
    // multiplicador do ataque do inimigo, multiplicador de pontos, descrição
    FACIL("Fácil", 150, 0.4, 0.3, 1, "Inimigo fraco e você começa com bastante vida."),
    NORMAL("Normal", 120, 0.7, 0.5, 2, "Um desafio equilibrado."),
    DIFICIL("Difícil", 100, 0.9, 0.6, 3, "Inimigo forte! Use bem seus itens.");

    // Os "atributos": os dados que cada dificuldade guarda.
    private String nome;
    private int vidaJogador;
    private double multVidaInimigo;
    private double multAtaqueInimigo;
    private int multPontos;
    private String descricao;

    // Construtor: preenche os dados de cada opção acima.
    Dificuldade(String nome, int vidaJogador, double multVidaInimigo,
                double multAtaqueInimigo, int multPontos, String descricao) {
        this.nome = nome;
        this.vidaJogador = vidaJogador;
        this.multVidaInimigo = multVidaInimigo;
        this.multAtaqueInimigo = multAtaqueInimigo;
        this.multPontos = multPontos;
        this.descricao = descricao;
    }

    // Getters: servem para outras classes lerem os dados.
    public String getNome() {
        return nome;
    }

    public int getVidaJogador() {
        return vidaJogador;
    }

    public int getMultPontos() {
        return multPontos;
    }

    public String getDescricao() {
        return descricao;
    }

    // Recebe a vida "normal" de um inimigo e devolve a vida ajustada.
    // Ex.: 360 de vida no FÁCIL (x0.4) vira 144.
    public int ajustaVida(int vidaBase) {
        return (int) Math.round(vidaBase * multVidaInimigo);
    }

    // Mesma ideia, mas para o ataque do inimigo.
    public int ajustaAtaque(int ataqueBase) {
        return (int) Math.round(ataqueBase * multAtaqueInimigo);
    }
}
