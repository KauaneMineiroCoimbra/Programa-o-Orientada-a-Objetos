// ============================================================
// Inimigo.java
// Classe-mãe dos monstros. Todo inimigo é uma Criatura
// que também tem um valor de ATAQUE.
// ============================================================
public abstract class Inimigo extends Criatura {
    private int ataque;  // quanto de dano o inimigo causa por golpe

    public Inimigo(String nome, int vida, int ataque) {
        super(nome, vida);  // manda nome e vida para a classe Criatura
        this.ataque = ataque;
    }

    public int getAtaque() {
        return ataque;
    }

    // O ataque do inimigo sempre causa o mesmo dano na vítima.
    @Override
    public void fazAtaque(Criatura criatura) {
        criatura.tomaDano(ataque);
    }
}
