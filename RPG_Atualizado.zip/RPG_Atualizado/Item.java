import java.util.Random;

// ============================================================
// Item.java  (NOVO)
// Classe-mãe de todos os ITENS do jogo.
//
// É "abstract" porque não existe um "item genérico": sempre é
// uma poção, um cristal, etc. Cada tipo de item (classe filha)
// decide o que acontece quando é usado (método usar).
// ============================================================
public abstract class Item {
    private String nome;       // nome que aparece na mochila
    private String descricao;  // explica o que o item faz

    public Item(String nome, String descricao) {
        this.nome = nome;
        this.descricao = descricao;
    }

    public String getNome() {
        return nome;
    }

    public String getDescricao() {
        return descricao;
    }

    // Cada item filho escreve o seu próprio efeito aqui.
    public abstract void usar(Jogador jogador);

    // Sorteia um item aleatório (50% poção, 50% cristal de um elemento).
    // É "static": dá para chamar direto com Item.sortear(...), sem criar objeto.
    public static Item sortear(Random sorteio) {
        if (sorteio.nextInt(2) == 0) {
            return new PocaoCura();
        }
        return CristalElemento.sortear(sorteio);
    }
}
