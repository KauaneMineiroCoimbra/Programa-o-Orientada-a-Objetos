// ============================================================
// Jogada.java  (NOVO)
// Representa UMA JOGADA (um golpe de magia) feita durante a batalha.
//
// Cada vez que alguém lança uma magia, criamos uma Jogada para
// "anotar" o que aconteceu: quem jogou, qual elemento, qual comando
// foi digitado, se acertou e quanto de dano causou.
// Assim o jogo consegue contar acertos, mostrar resumo e dar pontos.
// ============================================================
public class Jogada {
    private String quemJogou;   // nome de quem lançou a magia
    private String elemento;    // agua, fogo, terra ou vento
    private String comando;     // o que foi digitado (>>, <<, ^^)
    private boolean acertou;    // true = comando certo
    private int dano;           // dano causado no inimigo

    // Construtor: guarda tudo que aconteceu na jogada.
    public Jogada(String quemJogou, String elemento, String comando, boolean acertou, int dano) {
        this.quemJogou = quemJogou;
        this.elemento = elemento;
        this.comando = comando;
        this.acertou = acertou;
        this.dano = dano;
    }

    // Getters: permitem ler as informações guardadas.
    public String getQuemJogou() {
        return quemJogou;
    }

    public String getElemento() {
        return elemento;
    }

    public String getComando() {
        return comando;
    }

    public boolean acertou() {
        return acertou;
    }

    public int getDano() {
        return dano;
    }

    // Mostra a jogada em uma linha, para o resumo da batalha.
    public void mostrar() {
        String resultado = acertou ? "ACERTOU" : "errou o comando";
        System.out.println("• " + quemJogou + " usou " + elemento.toUpperCase()
                + " (" + comando + ") -> " + resultado + ", " + dano + " de dano.");
    }
}
