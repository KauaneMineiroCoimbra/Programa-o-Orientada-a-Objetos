import java.util.ArrayList;
import java.util.Scanner;

// ============================================================
// Jogador.java
// O aprendiz de feiticeiro controlado por quem joga.
// Guarda: nível de conhecimento, poder de cada elemento,
// quantos moradores ajudou e a MOCHILA com itens (novo).
// ============================================================
public class Jogador extends Criatura {
    private int nivelConhecimento = 1;
    private int poderAgua = 10;   // começa só com água liberada
    private int poderFogo = 0;    // 0 = ainda bloqueado
    private int poderTerra = 0;
    private int poderVento = 0;
    private int moradoresAjudados = 0;

    // (NOVO) Mochila: lista de itens que o jogador carrega.
    private ArrayList<Item> mochila = new ArrayList<>();
    // (NOVO) Cópia da mochila, usada para "reabastecer" quando tenta a batalha de novo.
    private ArrayList<Item> mochilaSalva = new ArrayList<>();

    // (NOVO) Agora a vida inicial vem de fora, porque depende da dificuldade.
    public Jogador(String nome, int vidaInicial) {
        super(nome, vidaInicial);
    }

    // Construtor antigo: vida padrão de 120 (continua funcionando).
    public Jogador(String nome) {
        super(nome, 120);
    }

    public int getNivelConhecimento() {
        return nivelConhecimento;
    }

    public int getMoradoresAjudados() {
        return moradoresAjudados;
    }

    // Chamado quando o jogador termina de ajudar um morador.
    public void ajudouMorador() {
        moradoresAjudados++;
        aumentarConhecimento(1);
    }

    public void aumentarConhecimento(int quantidade) {
        nivelConhecimento += quantidade;
        System.out.println("★ Seu conhecimento mágico aumentou para nível " + nivelConhecimento + "!");
    }

    // Libera um elemento que estava bloqueado (dá o poder inicial dele).
    public void desbloquear(String elemento) {
        if (elemento.equals("fogo")) {
            poderFogo = 18;
        } else if (elemento.equals("terra")) {
            poderTerra = 24;
        } else if (elemento.equals("vento")) {
            poderVento = 30;
        }
    }

    // Treinar um elemento: aumenta o poder dele em 4 (se já estiver liberado).
    public void praticar(String elemento) {
        if (elemento.equals("agua")) {
            poderAgua += 4;
            System.out.println("A água dança ao redor de suas mãos!");
            System.out.println("Poder da Água: " + poderAgua);
        } else if (elemento.equals("fogo") && poderFogo > 0) {
            poderFogo += 4;
            System.out.println("A chama fica mais firme!");
            System.out.println("Poder do Fogo: " + poderFogo);
        } else if (elemento.equals("terra") && poderTerra > 0) {
            poderTerra += 4;
            System.out.println("O chão responde ao seu chamado!");
            System.out.println("Poder da Terra: " + poderTerra);
        } else if (elemento.equals("vento") && poderVento > 0) {
            poderVento += 4;
            System.out.println("O vento gira em volta do cajado!");
            System.out.println("Poder do Vento: " + poderVento);
        }
    }

    // (NOVO) Aumenta o poder de um elemento por uma quantidade qualquer.
    // É usado pelo CristalElemento. Elemento bloqueado (poder 0) não é aumentado.
    public void aumentarPoder(String elemento, int quantidade) {
        if (elemento.equals("agua")) {
            poderAgua += quantidade;
        } else if (elemento.equals("fogo") && poderFogo > 0) {
            poderFogo += quantidade;
        } else if (elemento.equals("terra") && poderTerra > 0) {
            poderTerra += quantidade;
        } else if (elemento.equals("vento") && poderVento > 0) {
            poderVento += quantidade;
        }
    }

    // Mostra o "Livro do Aprendiz" com todas as informações.
    public void mostraStatus() {
        System.out.println("\n========== LIVRO DO APRENDIZ ==========");
        mostraVida();
        System.out.println("Aprendiz: " + getNome());
        System.out.println("Nível de conhecimento: " + nivelConhecimento);
        System.out.println("Água: " + poderAgua);
        System.out.println("Fogo: " + (poderFogo == 0 ? "bloqueado" : poderFogo));
        System.out.println("Terra: " + (poderTerra == 0 ? "bloqueado" : poderTerra));
        System.out.println("Vento: " + (poderVento == 0 ? "bloqueado" : poderVento));
        System.out.println("Moradores ajudados: " + moradoresAjudados + "/5");
        System.out.println("Itens na mochila: " + mochila.size());  // (NOVO)
        System.out.println("========================================");
    }

    // Devolve o poder (dano base) do elemento pedido.
    private int poder(String elemento) {
        if (elemento.equals("agua")) return poderAgua;
        if (elemento.equals("fogo")) return poderFogo;
        if (elemento.equals("terra")) return poderTerra;
        return poderVento;
    }

    // (NOVO) Diz qual é o comando CERTO de cada elemento.
    // Antes isso estava "escondido" dentro do lancarMagia; agora é público
    // para o robô simulador também poder usar.
    public static String comandoCerto(String elemento) {
        if (elemento.equals("fogo")) return "^^";
        if (elemento.equals("terra")) return "<<";
        return ">>";  // água e vento usam >>
    }

    // ---------------- JOGADA (com pergunta ao jogador) ----------------
    // Pergunta o comando pelo teclado e depois lança a magia.
    // Agora DEVOLVE uma Jogada, que anota o que aconteceu.
    public Jogada lancarMagia(String elemento, Inimigo inimigo, Scanner sc) {
        // Se o elemento ainda está bloqueado, nem pergunta o comando.
        if (poder(elemento) <= 0) {
            System.out.println("Essa magia ainda está bloqueada.");
            return new Jogada(getNome(), elemento, "-", false, 0);
        }

        System.out.println("\nEscolha o comando mágico para " + elemento.toUpperCase() + ":");
        System.out.println("1) >>");
        System.out.println("2) <<");
        System.out.println("3) ^^");
        System.out.print("Comando: ");
        String comando = sc.nextLine().trim();

        return lancarMagia(elemento, inimigo, comando);
    }

    // ---------------- JOGADA (comando já escolhido) ----------------
    // Faz o ataque de verdade. Existe separado para o robô poder
    // jogar sem digitar nada no teclado.
    public Jogada lancarMagia(String elemento, Inimigo inimigo, String comando) {
        int dano = poder(elemento);
        if (dano <= 0) {
            System.out.println("Essa magia ainda está bloqueada.");
            return new Jogada(getNome(), elemento, comando, false, 0);
        }

        // Acertou se o comando digitado é o comando certo daquele elemento.
        boolean acertou = comando.equals(comandoCerto(elemento));
        int danoCausado;

        if (acertou) {
            System.out.println("✨ FEITIÇO CONJURADO! ✨");
            danoCausado = dano;                      // dano total
        } else {
            System.out.println("O comando saiu torto! O feitiço perdeu força.");
            danoCausado = Math.max(5, dano / 3);     // dano fraquinho (mínimo 5)
        }

        inimigo.tomaDano(danoCausado);
        return new Jogada(getNome(), elemento, comando, acertou, danoCausado);
    }

    // ---------------- ITENS / MOCHILA (NOVO) ----------------

    // Coloca um item na mochila.
    public void ganharItem(Item item) {
        mochila.add(item);
        System.out.println("🎁 Você ganhou: " + item.getNome() + " — " + item.getDescricao());
    }

    public boolean temItens() {
        return !mochila.isEmpty();
    }

    public int quantidadeItens() {
        return mochila.size();
    }

    // Lista os itens da mochila, numerados a partir do 1.
    public void mostrarMochila() {
        System.out.println("\n----- MOCHILA -----");
        for (int i = 0; i < mochila.size(); i++) {
            Item item = mochila.get(i);
            System.out.println((i + 1) + ") " + item.getNome() + " — " + item.getDescricao());
        }
    }

    // Usa o item da posição "indice" (começando em 0) e o tira da mochila.
    public void usarItem(int indice) {
        Item item = mochila.remove(indice);
        item.usar(this);  // cada tipo de item faz o seu efeito
    }

    // Usa a primeira poção que achar. Devolve false se não tinha nenhuma.
    // "instanceof" pergunta: este item é uma PocaoCura?
    public boolean usarPocao() {
        for (int i = 0; i < mochila.size(); i++) {
            if (mochila.get(i) instanceof PocaoCura) {
                usarItem(i);
                return true;
            }
        }
        return false;
    }

    // Usa todos os cristais da mochila de uma vez.
    public void usarCristais() {
        int i = 0;
        while (i < mochila.size()) {
            if (mochila.get(i) instanceof CristalElemento) {
                usarItem(i);   // o item sai da lista, então NÃO avançamos o i
            } else {
                i++;           // não era cristal: olha o próximo
            }
        }
    }

    // Guarda uma cópia da mochila atual (chamado antes da batalha).
    public void salvarMochila() {
        mochilaSalva = new ArrayList<>(mochila);
    }

    // Devolve a mochila ao que estava antes da batalha (ajuda ao tentar de novo).
    public void restaurarMochila() {
        mochila = new ArrayList<>(mochilaSalva);
    }

    // ---------------- Frases do Criatura ----------------

    // Ataque simples do jogador (usa o poder da água).
    @Override
    public void fazAtaque(Criatura criatura) {
        criatura.tomaDano(poderAgua);
    }

    @Override
    public void fraseApresentacao() {
        System.out.println("Eu ainda sou um pequeno aprendiz, mas vou aprender!");
    }

    @Override
    public void fraseMorte() {
        System.out.println("Meu livro de magia caiu no chão...");
    }
}
