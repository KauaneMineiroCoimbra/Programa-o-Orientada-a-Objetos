// ============================================================
// Mentor.java  (NOVO)
// Tipo de NPC: o Professor Walter.
// Ele ensina e dá DICAS dos comandos mágicos, mas só algumas vezes.
// ============================================================
public class Mentor extends Npc {
    private int dicasRestantes = 3;  // quantas dicas ainda pode dar

    public Mentor() {
        super("Professor Walter");
    }

    public int getDicasRestantes() {
        return dicasRestantes;
    }

    @Override
    public void fraseApresentacao() {
        System.out.println("Professor Walter: Eu sou seu mentor. Posso te dar até "
                + dicasRestantes + " dicas durante o jogo.");
    }

    // Quando o jogador conversa com o mentor, ele dá uma dica.
    @Override
    public void interagir(Jogador jogador) {
        // Se as dicas acabaram, ele só incentiva.
        if (dicasRestantes <= 0) {
            System.out.println("Professor Walter: Já te ajudei bastante! Confie na sua memória.");
            return;
        }

        dicasRestantes--;  // gasta uma dica
        System.out.println("\nProfessor Walter: Lembre-se dos comandos mágicos:");
        System.out.println("  Água  = >>");
        System.out.println("  Fogo  = ^^");
        System.out.println("  Terra = <<");
        System.out.println("  Vento = >>");
        System.out.println("(Dicas restantes: " + dicasRestantes + ")");
    }
}
