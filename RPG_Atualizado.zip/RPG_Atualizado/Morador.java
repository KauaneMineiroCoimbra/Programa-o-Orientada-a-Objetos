// ============================================================
// Morador.java  (NOVO)
// Tipo de NPC: os moradores da vila que pedem ajuda no jardim.
// Depois de ajudados, eles dão um ITEM de presente para o jogador.
// ============================================================
public class Morador extends Npc {
    private String praga;       // qual praga está no jardim dele
    private Item recompensa;    // presente que ele dá ao final

    public Morador(String nome, String praga, Item recompensa) {
        super(nome);
        this.praga = praga;
        this.recompensa = recompensa;
    }

    // O morador chega pedindo ajuda.
    @Override
    public void fraseApresentacao() {
        System.out.println(getNome() + ": Socorro, jovem feiticeiro! Meu jardim está com " + praga + "!");
    }

    // Depois que o jogador ajuda, o morador agradece e entrega o item.
    @Override
    public void interagir(Jogador jogador) {
        System.out.println(getNome() + ": Muito obrigado! Aceite este presente.");
        jogador.ganharItem(recompensa);
    }
}
