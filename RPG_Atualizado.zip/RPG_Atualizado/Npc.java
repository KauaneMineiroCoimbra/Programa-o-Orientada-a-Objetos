// ============================================================
// Npc.java  (NOVO)
// NPC = "personagem não jogável": quem não é controlado pelo jogador.
// Eles conversam, ajudam, dão itens... mas não lutam.
//
// Esta é a classe-mãe de todos os tipos de NPC (Mentor, Morador,
// Curandeira). Ela herda de Criatura, então todo NPC tem nome e vida.
// ============================================================
public abstract class Npc extends Criatura {

    public Npc(String nome) {
        super(nome, 100);  // NPCs não lutam, a vida é só para cumprir o "molde" de Criatura
    }

    // Cada tipo de NPC faz uma coisa diferente quando o jogador conversa com ele.
    public abstract void interagir(Jogador jogador);

    // Criatura obriga todo mundo a ter "fazAtaque". NPCs são pacíficos.
    @Override
    public void fazAtaque(Criatura criatura) {
        System.out.println(getNome() + " é pacífico e não ataca ninguém.");
    }

    // Frase padrão de despedida (os filhos podem trocar se quiserem).
    @Override
    public void fraseMorte() {
        System.out.println(getNome() + " some em uma nuvem de brilho...");
    }
}
