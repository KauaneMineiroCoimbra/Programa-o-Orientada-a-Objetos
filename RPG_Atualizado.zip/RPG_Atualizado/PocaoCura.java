// ============================================================
// PocaoCura.java  (NOVO)
// Um tipo de Item: a poção que recupera vida do jogador.
// ============================================================
public class PocaoCura extends Item {
    private static final int CURA = 40;  // quanto de vida a poção devolve

    public PocaoCura() {
        super("Poção de Cura", "Recupera " + CURA + " de vida.");
    }

    // O que acontece quando o jogador usa a poção.
    @Override
    public void usar(Jogador jogador) {
        System.out.println("🧪 Você bebeu a Poção de Cura!");
        jogador.cura(CURA);  // a vida nunca passa do máximo (isso já é tratado em Criatura)
        jogador.mostraVida();
    }
}
