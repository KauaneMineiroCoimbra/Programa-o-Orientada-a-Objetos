RPG ESCOLA ARCANA DE VALE-LUME
Criado por Julia

COMO EXECUTAR
1. Coloque todos os arquivos .java na mesma pasta.
2. Abra a pasta no IntelliJ, VS Code ou NetBeans.
3. Execute a classe Jogo.java.
   (Se os símbolos/emojis aparecerem estranhos, configure o projeto para UTF-8.)

IDEIA DO PROJETO
O jogador é um aprendiz de feiticeiro que chega à Escola Arcana de Vale-Lume.
O Professor Walter ensina quatro elementos, usando comandos simples:
>>  <<  ^^

NOVIDADES (ideias do Grupo 4)
- MENU PRINCIPAL: jogar, ver simulação, ver ranking ou sair.
- NÍVEIS DE DIFICULDADE (Dificuldade.java): Fácil, Normal e Difícil mudam a vida
  do jogador, a força do Boots e o multiplicador de pontos.
- JOGADA (Jogada.java): cada magia lançada é anotada (elemento, comando,
  acerto, dano). Ao fim da batalha aparece um resumo.
- NPCs de vários tipos (Npc.java):
    Mentor (Professor Walter)  -> dá até 3 dicas dos comandos.
    Morador                    -> pede ajuda e dá um item de presente.
    Curandeira (Fada Lumi)     -> cura o jogador e dá uma poção.
- ITENS / ELEMENTOS (Item.java):
    Poção de Cura              -> recupera vida.
    Cristal de Água/Fogo/Terra/Vento -> aumenta o poder do elemento.
  Os itens ficam na mochila e podem ser usados durante a batalha.
- RANKING (Ranking.java): os 10 melhores ficam salvos no arquivo ranking.txt.
- SIMULAÇÃO ALEATÓRIA DE JOGADOR (SimuladorJogador.java): um robô joga sozinho,
  tomando decisões ao acaso, e também entra no ranking se vencer.

ARQUIVOS
Jogo.java ............ história, menu, batalha e ranking
Jogador.java ......... o aprendiz (poderes, mochila, magias)
Criatura.java ........ base de todos os seres (nome e vida)
Inimigo.java, Boots.java, Demonion.java, Malignus.java ... monstros
Npc.java, Mentor.java, Morador.java, Curandeira.java ..... NPCs (novo)
Item.java, PocaoCura.java, CristalElemento.java .......... itens (novo)
Jogada.java, Dificuldade.java, Ranking.java, SimuladorJogador.java (novo)
LivroMagia.java ...... bestiário das pragas

OBSERVAÇÃO SOBRE O EQUILÍBRIO
Na versão original, o Boots (360 de vida) era praticamente impossível de vencer.
Agora a dificuldade ajusta o Boots, e os itens dados pelos moradores ajudam na luta.

O jogo foi mantido com conceitos de Java de nível iniciante:
classes, herança, atributos, métodos, if/else, while, for, Scanner,
objetos, polimorfismo simples, listas (ArrayList) e entrada do usuário.

DURAÇÃO
Sessão de aproximadamente 30-40 minutos dependendo da velocidade de leitura.
