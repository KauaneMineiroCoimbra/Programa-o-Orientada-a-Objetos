import java.io.File;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

// ============================================================
// Ranking.java  (NOVO)
// Guarda os MELHORES JOGADORES, do maior para o menor número de pontos.
// Os dados ficam salvos no arquivo "ranking.txt", então o ranking
// continua existindo mesmo depois de fechar o jogo.
// ============================================================
public class Ranking {
    private static final String ARQUIVO = "ranking.txt";  // onde o ranking é salvo
    private static final int MAXIMO = 10;                  // só guardamos os 10 melhores

    // Três listas "paralelas": a posição 0 de cada lista é do mesmo jogador.
    private ArrayList<String> nomes = new ArrayList<>();
    private ArrayList<Integer> pontos = new ArrayList<>();
    private ArrayList<String> niveis = new ArrayList<>();

    // Ao criar o Ranking, já lemos o que estava salvo no arquivo.
    public Ranking() {
        carregar();
    }

    // Calcula a pontuação final de uma partida.
    // Ganha pontos por: conhecimento, moradores ajudados, vida que sobrou e acertos.
    // Perde pontos por cada tentativa extra na batalha.
    // No fim multiplica pela dificuldade (mais difícil = mais pontos).
    public static int calcularPontos(int conhecimento, int moradores, int vidaRestante,
                                     int acertos, int tentativas, Dificuldade dificuldade) {
        int total = conhecimento * 10
                + moradores * 20
                + vidaRestante
                + acertos * 5
                - (tentativas - 1) * 40;

        if (total < 0) {
            total = 0;  // pontuação nunca fica negativa
        }
        return total * dificuldade.getMultPontos();
    }

    // Coloca um jogador no ranking já na posição certa.
    // Devolve a colocação (1, 2, 3...) ou 0 se ficou fora do top 10.
    public int adicionar(String nome, int pontuacao, String nivel) {
        nome = nome.replace(";", " ");  // o ";" é usado para separar dados no arquivo

        // Procura a posição: anda enquanto os pontos de quem já está lá forem maiores ou iguais.
        int posicao = 0;
        while (posicao < pontos.size() && pontos.get(posicao) >= pontuacao) {
            posicao++;
        }

        nomes.add(posicao, nome);
        pontos.add(posicao, pontuacao);
        niveis.add(posicao, nivel);

        // Se passou de 10 jogadores, remove o último (o pior).
        while (nomes.size() > MAXIMO) {
            int ultimo = nomes.size() - 1;
            nomes.remove(ultimo);
            pontos.remove(ultimo);
            niveis.remove(ultimo);
        }

        salvar();

        if (posicao >= MAXIMO) {
            return 0;
        }
        return posicao + 1;
    }

    // Mostra a tabela do ranking na tela.
    public void mostrar() {
        System.out.println("\n╔══════════════════════════════════════════════╗");
        System.out.println("║               🏆 RANKING 🏆                  ║");
        System.out.println("╚══════════════════════════════════════════════╝");

        if (nomes.isEmpty()) {
            System.out.println("Ainda não há ninguém no ranking. Seja o primeiro!");
            return;
        }

        for (int i = 0; i < nomes.size(); i++) {
            System.out.println((i + 1) + "º  " + nomes.get(i)
                    + "  —  " + pontos.get(i) + " pontos  (" + niveis.get(i) + ")");
        }
    }

    // Lê o arquivo ranking.txt. Cada linha tem o formato: nome;pontos;nivel
    private void carregar() {
        File arquivo = new File(ARQUIVO);
        if (!arquivo.exists()) {
            return;  // primeira vez jogando: não tem arquivo ainda
        }

        // "try" tenta fazer; se der erro, o "catch" evita que o jogo quebre.
        try (Scanner leitor = new Scanner(arquivo, "UTF-8")) {
            while (leitor.hasNextLine()) {
                String[] partes = leitor.nextLine().split(";");
                if (partes.length == 3) {
                    nomes.add(partes[0]);
                    pontos.add(Integer.parseInt(partes[1]));
                    niveis.add(partes[2]);
                }
            }
        } catch (Exception e) {
            System.out.println("(Não consegui ler o ranking salvo. Começando um novo.)");
            nomes.clear();
            pontos.clear();
            niveis.clear();
        }
    }

    // Escreve o ranking inteiro no arquivo.
    private void salvar() {
        try (PrintWriter escritor = new PrintWriter(ARQUIVO, "UTF-8")) {
            for (int i = 0; i < nomes.size(); i++) {
                escritor.println(nomes.get(i) + ";" + pontos.get(i) + ";" + niveis.get(i));
            }
        } catch (Exception e) {
            System.out.println("(Não consegui salvar o ranking.)");
        }
    }
}
