import java.util.ArrayList;
import java.util.Random;

// ============================================================
// SimuladorJogador.java  (NOVO)
// SISTEMA DE SIMULAÇÃO ALEATÓRIA DE JOGADOR.
//
// Um "robô" joga a aventura sozinho, tomando decisões ao acaso:
//   - sorteia qual elemento vai treinar;
//   - ganha itens sorteados dos moradores;
//   - na batalha escolhe elementos aleatórios, com uma chance de
//     errar o comando (como um jogador humano distraído);
//   - bebe poção quando a vida está baixa.
// No fim, se vencer, entra no ranking.
// ============================================================
public class SimuladorJogador {
    private static final int CHANCE_ACERTO = 75;   // 75% de chance de digitar o comando certo
    private static final int MAX_TENTATIVAS = 5;   // o robô desiste depois de 5 derrotas
    private static final String[] ELEMENTOS = {"agua", "fogo", "terra", "vento"};

    private Random sorteio = new Random();  // "dado" que gera os números aleatórios
    private Dificuldade dificuldade;
    private Ranking ranking;

    public SimuladorJogador(Dificuldade dificuldade, Ranking ranking) {
        this.dificuldade = dificuldade;
        this.ranking = ranking;
    }

    // Roda a simulação completa do começo ao fim.
    public void simular() {
        System.out.println("\n🤖 SIMULAÇÃO: o Robô Aprendiz vai jogar sozinho! (Dificuldade: "
                + dificuldade.getNome() + ")");

        Jogador robo = new Jogador("Robô Aprendiz", dificuldade.getVidaJogador());

        // 1) O robô "aprende" as aulas: libera os elementos e ganha conhecimento.
        System.out.println("\n--- O robô assiste às aulas ---");
        robo.desbloquear("fogo");
        robo.desbloquear("terra");
        robo.desbloquear("vento");
        robo.aumentarConhecimento(4);

        // 2) Treino livre: 3 treinos em elementos sorteados.
        System.out.println("\n--- O robô treina 3 vezes ---");
        for (int i = 1; i <= 3; i++) {
            String elemento = ELEMENTOS[sorteio.nextInt(ELEMENTOS.length)];
            System.out.println("Treino " + i + ": o robô sorteou " + elemento.toUpperCase());
            robo.praticar(elemento);
            robo.aumentarConhecimento(1);
        }

        // 3) Ajuda 5 moradores e ganha um item sorteado de cada um.
        System.out.println("\n--- O robô ajuda os moradores ---");
        for (int i = 1; i <= 5; i++) {
            robo.ganharItem(Item.sortear(sorteio));
            robo.ajudouMorador();
        }

        // 4) Batalha final contra o Boots.
        batalha(robo);
    }

    // Parte da batalha. Fica separada só para o código ficar organizado.
    private void batalha(Jogador robo) {
        System.out.println("\n--- O robô enfrenta o BOOTS! ---");

        robo.salvarMochila();  // guarda os itens para reabastecer a cada tentativa

        ArrayList<Jogada> historico = new ArrayList<>();  // todas as jogadas do robô
        int acertos = 0;
        int tentativa = 1;
        boolean venceu = false;

        while (!venceu && tentativa <= MAX_TENTATIVAS) {
            System.out.println("\n===== SIMULAÇÃO — TENTATIVA " + tentativa + " =====");
            robo.restauraVida();
            robo.restaurarMochila();
            robo.usarCristais();                         // usa os cristais antes de lutar
            Boots boots = new Boots(dificuldade);

            while (robo.estaVivo() && boots.estaVivo()) {
                robo.mostraVida();
                boots.mostraVida();

                // Se a vida está abaixo de 40%, tenta beber uma poção.
                boolean vidaBaixa = robo.getVida() * 100 < robo.getVidaMaxima() * 40;
                if (vidaBaixa && robo.usarPocao()) {
                    System.out.println("🤖 O robô bebeu uma poção.");
                } else {
                    // Sorteia o elemento e decide se vai acertar o comando.
                    String elemento = ELEMENTOS[sorteio.nextInt(ELEMENTOS.length)];
                    String comando = escolherComando(elemento);
                    System.out.println("🤖 O robô escolheu " + elemento.toUpperCase()
                            + " e digitou " + comando);

                    Jogada jogada = robo.lancarMagia(elemento, boots, comando);
                    historico.add(jogada);
                    if (jogada.acertou()) {
                        acertos++;
                    }
                }

                // O Boots contra-ataca se ainda estiver de pé.
                if (boots.estaVivo()) {
                    boots.fazAtaque(robo);
                }
            }

            if (robo.estaVivo()) {
                boots.fraseMorte();
                venceu = true;
            } else {
                System.out.println("💫 O robô foi derrotado e vai tentar de novo.");
                tentativa++;
            }
        }

        mostrarResultado(robo, venceu, acertos, tentativa, historico.size());
    }

    // Decide o comando digitado: certo (75%) ou um comando errado (25%).
    private String escolherComando(String elemento) {
        String certo = Jogador.comandoCerto(elemento);

        // nextInt(100) gera um número de 0 a 99.
        if (sorteio.nextInt(100) < CHANCE_ACERTO) {
            return certo;
        }

        // Errou: sorteia comandos até achar um diferente do certo.
        String[] comandos = {">>", "<<", "^^"};
        String errado = certo;
        while (errado.equals(certo)) {
            errado = comandos[sorteio.nextInt(comandos.length)];
        }
        return errado;
    }

    // Mostra como foi a simulação e coloca o robô no ranking se ele venceu.
    private void mostrarResultado(Jogador robo, boolean venceu, int acertos, int tentativa, int totalJogadas) {
        System.out.println("\n========== RESULTADO DA SIMULAÇÃO ==========");
        System.out.println("Jogadas feitas: " + totalJogadas);
        System.out.println("Comandos certos: " + acertos);

        if (!venceu) {
            System.out.println("O robô desistiu depois de " + MAX_TENTATIVAS + " tentativas. Ele não entra no ranking.");
            return;
        }

        int pontos = Ranking.calcularPontos(robo.getNivelConhecimento(), robo.getMoradoresAjudados(),
                robo.getVida(), acertos, tentativa, dificuldade);
        System.out.println("O robô venceu na tentativa " + tentativa + " e fez " + pontos + " pontos!");

        int colocacao = ranking.adicionar("🤖 Robô Aprendiz", pontos, dificuldade.getNome());
        if (colocacao > 0) {
            System.out.println("Ele ficou em " + colocacao + "º lugar no ranking!");
        }
    }
}
